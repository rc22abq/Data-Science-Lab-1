# -*- coding: utf-8 -*-
"""
Created on Wed Mar  8 21:41:49 2023

@author: User
"""

import requests
import numpy as np
import calendar
import statistics as stat
import matplotlib.pyplot as plt

# Define URL.
data = 'https://www.metoffice.gov.uk/hadobs/hadcet/data/meantemp_monthly_totals.txt'

# Use requests.
r = requests.get(data)

# Get the text.
data2 = r.text

# Split it into lines based on newline character.
lines = data2.split('\n')

# Lists to store months with highest temperatures, and the temperature itself
max_temp_month = []
max_temp_temp = []

# Loop over lines - starting at index 4
# since there are 4 header lines to ignore
for line in lines[4:-1]:        # -1 as latest year has incomplete data for 2023
    # Split it into a list where the separator is any whitespace
    line_new = line.split()
    # Our list will be full of strings. We need to convert these into floats.
    line_new_float = [float(i) for i in line_new[1:13]]
    # Find the max temperature
    max_temp = max(line_new_float)
    # Find the month in which the max temperature is achieved
    index_max = line_new_float.index(max_temp)
    # Change number into month, accounting for the indexing
    month_max = calendar.month_name[index_max+1]
    # Add this month to the list of months with highest temperatures
    max_temp_month.append(month_max)
    max_temp_temp.append(max_temp)
    
# Now let's summarise what we have found    
print('The months with the highest temperature are given as follows:\n\n',
      max_temp_month)
print('\nand the maximum temperatures respectively are:\n\n',max_temp_temp)
print('\nThe most common month with highest temperature is',
      stat.mode(max_temp_month))
print('The average temperature in',stat.mode(max_temp_month),
      'was',stat.mean(max_temp_temp),'degrees')

# Finally, we print out the hottest month/year ever
hottest_temp = max(max_temp_temp)
hottest_month = max_temp_month[max_temp_temp.index(hottest_temp)]
hottest_year = 1659+max_temp_temp.index(hottest_temp)
print('\nThe hottest temperature recorded was',hottest_temp,
      'and it was in',hottest_month, hottest_year)
